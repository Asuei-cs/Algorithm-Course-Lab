package Graph;

public class VertexNode {
    String data; // 顶点域，存储顶点信息
    EdgeNode firstedge; // 边表头

    public VertexNode(String data) {
        this.data = data;
        this.firstedge = null;
    }
}
