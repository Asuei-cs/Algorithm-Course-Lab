package Graph;

public class EdgeNode {
    int vex;
    int adjvex; // 邻接点域，存储该顶点对应的下标
    int index;
    EdgeNode next;
    EdgeNode prior;

    public EdgeNode(int vex, int adjvex) {
        this.vex = vex;
        this.adjvex = adjvex;
        this.next = null;
        this.prior=null;
    }
    public EdgeNode(int vex, int adjvex,int index) {
        this.vex = vex;
        this.adjvex = adjvex;
        this.next = null;
        this.prior=null;
        this.index=index;
    }
    public void setIndex(int index) {
        this.index = index;
    }
}
