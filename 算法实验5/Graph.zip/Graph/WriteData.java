package Graph;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import static java.lang.Math.sqrt;

public class WriteData {
    public static int nodeNum=1000;

    public static void main(String[] args) throws IOException {

        String writeFile1="src/Graph/data/random.txt";
        WriteData.readFile(writeFile1);
    }
    public static void readFile( String writeFile1) throws IOException {

        FileWriter fw1 =new FileWriter(writeFile1);//创建一个读取流对象和文件相关联

        BufferedWriter writer1;
        try {

            writer1 = new BufferedWriter(fw1);
            int line=(int)(nodeNum*5);
            Random rd = new Random();
            writer1.write(nodeNum+"");
            writer1.newLine();
            writer1.write(nodeNum*5+"");
            writer1.newLine();
            while (line>0) {
                int index1 = rd.nextInt(nodeNum) ;
                int index2 = rd.nextInt(nodeNum) ;
                if(index1>=index2)continue;
                String e = index1 + " " + index2;
                line--;
                writer1.write(e);
                writer1.newLine();
                writer1.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}