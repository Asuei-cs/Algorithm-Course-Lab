package Graph;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


public class Graph {

    private ArrayList<VertexNode> vexs; // 顶点表
    int numVertexes;
    int numEdges;
    boolean[] visited;
    Set<EdgeNode> edgeNodeSet=new HashSet<>();
    HashMap<Integer,Set<Integer>> UFset=new HashMap<>();
    int []fartherV;
    int []vexFarther;
    int []vexDepth;
    Set<Integer>vexRoot=new HashSet<>();
    int treeEdges=0;
    int []isTreeEdges;
    Set<Integer> notEdgesIndex=new HashSet<>();

    public Graph(int numVertexes, int numEdges) {
        this.numVertexes = numVertexes;
        this.numEdges = numEdges;
        this.vexs = new ArrayList<VertexNode>(numVertexes);
        this.visited = new boolean[numVertexes];
        fartherV=new int[numVertexes];
        for (int i=0;i<numVertexes;i++){
            VertexNode v=new VertexNode(i+"");
            insertVex(v);
        }
    }

    public  int  UFgetCC(int index){
    for (int i=0;i<numVertexes;i++){
        fartherV[i]=i;
        Set<Integer> set=new HashSet<>();
        set.add(i);
        UFset.put(i,set);
    }
        for (EdgeNode e:edgeNodeSet){
            if(e.index==index) continue;
            int i=e.vex;
            int j=e.adjvex;
            if(fartherV[i]==fartherV[j]){
                notEdgesIndex.add(e.index);
                continue;
            }
            Set<Integer> v1set=UFset.get(fartherV[i]);
            Set<Integer> v2set=UFset.get(fartherV[j]);

            if(v1set.size()>v2set.size()) {
                v1set.addAll(v2set);
                UFset.replace(fartherV[i], v1set);
                UFset.remove(fartherV[j], v2set);
                for (int v : v2set)
                    fartherV[v] = fartherV[i];
            }else {
                v2set.addAll(v1set);
                UFset.replace(fartherV[j], v2set);
                UFset.remove(fartherV[i], v1set);
                for (int v : v1set)
                    fartherV[v] = fartherV[j];
            }
        }
       // System.out.println(UFset.toString());
       return UFset.size();
}
    public void insertVex(VertexNode v) {
        vexs.add(v);
    }

    public void insertEdge(EdgeNode e) {

        int i = e.vex; // 顶点表中对应结点的下标
        int j = e.adjvex; // 边表结点对应的下标
        VertexNode vexi = vexs.get(i);
        VertexNode vexj = vexs.get(j);
        if(vexi.firstedge==null){
            vexi.firstedge=e;
        }else {
            vexi.firstedge.prior=e;
            e.next = vexi.firstedge;
            e.prior=null;
            vexi.firstedge = e;

        }

        EdgeNode e2 = new EdgeNode(j, i);
        e2.setIndex(e.index+numEdges);
        if(vexj.firstedge==null){
            vexj.firstedge=e2;
        }else {
            vexj.firstedge.prior=e2;
            e2.next = vexj.firstedge;
            e2.prior=null;
            vexj.firstedge = e2;
        }
    }

    public void deleteEdge(EdgeNode e) {
        int i = e.vex; // 顶点表中对应结点的下标
        int j = e.adjvex; // 边表结点对应的下标
        VertexNode vexi = vexs.get(i);
        VertexNode vexj = vexs.get(j);
        EdgeNode nodei = vexi.firstedge;
        while (nodei != null) {
           if(e.index==nodei.index){
               if(nodei.next==null){
                   if(nodei.prior==null){
                       vexi.firstedge=null;
                       break;
                   }
               }
               if(nodei.prior==null){
                   nodei.next.prior=null;
                   vexi.firstedge=nodei.next;
               }else
                    nodei.prior.next=nodei.next;

               if(nodei.next!=null)
                    nodei.next.prior=nodei.prior;
               else {
                   nodei.prior.next=null;
               }
               break;
           }else {
               nodei = nodei.next;
           }
        }

        EdgeNode nodej = vexj.firstedge;
        while (nodej != null) {
            if(e.index+numEdges==nodej.index){

                if(nodej.next==null){
                    if(nodej.prior==null){
                        vexj.firstedge=null;
                        break;
                    }
                }

                if(nodej.prior==null){
                    nodej.next.prior=null;
                    vexj.firstedge=nodej.next;
                }else
                    nodej.prior.next=nodej.next;

                if(nodej.next!=null)
                    nodej.next.prior=nodej.prior;
                else {
                    nodej.prior.next=null;
                }
                break;
            }else {
                nodej = nodej.next;
            }
        }
    }
    public void show() {
        for (int i = 0; i < numVertexes; i++) {
            VertexNode vex = vexs.get(i);
            System.out.print("【" + vex.data + "】—>");
            EdgeNode node = vex.firstedge;
            while (node != null) {
                System.out.print(vexs.get(node.adjvex).data + "->");
                node = node.next;
            }
            System.out.print("null");
            System.out.println();
        }
    }
    public void LCA_DFS(int index,int depth,int father,int root){
       vexDepth[index]=depth;
       vexFarther[index]=father;
        vexRoot.add(root);
        EdgeNode p = vexs.get(index).firstedge;
        while (p != null) {
            if (!visited[p.adjvex]) {
                visited[index] = true;
                treeEdges++;
                if(p.index>=numEdges)
                    isTreeEdges[p.index-numEdges]=1;
                else
                    isTreeEdges[p.index]=1;
                LCA_DFS(p.adjvex,depth+1,index,root);
            }
            p = p.next;
        }
    }
    public int LCA_DFS_ALL(){
        vexDepth=new int[numVertexes];
        vexFarther=new int[numVertexes];
        isTreeEdges=new int[numEdges];
        for (int i = 0; i < numVertexes; i++) {
            visited[i] = false;
        }
        for (int i = 0; i < numVertexes; i++){
            if(!visited[i])
                LCA_DFS(i,0,i,i);
        }
       for(EdgeNode e:edgeNodeSet){
           if(isTreeEdges[e.index]==0){
               LCA(e.vex,e.adjvex);
           }
       }
        return treeEdges;
    }
    public void LCA(int u,int v){
        if(vexFarther[u]==v||vexFarther[v]==u)
            return;
        int i=u;int j=v;
        while (true){
            if(vexDepth[u]>vexDepth[v]){
                treeEdges--;
                u=vexFarther[u];
            }
            else if(vexDepth[v]>vexDepth[u]){
                treeEdges--;
                v=vexFarther[v];
            }
            else {
                if(u!=v){
                    u=vexFarther[u];
                    v=vexFarther[v];
                }
                else
                    break;
            }
        }
        Unzip(i,u);
        Unzip(j,v);
    }
    private void Unzip(int x,int v){
        if(vexFarther[x]==v)
            return;
        else {
            int temx = x;
            x = vexFarther[x];
            vexFarther[temx] = v;
            Unzip(x,v);
        }
    }
    private void DFS(int i) {
        EdgeNode p;
        visited[i] = true;
      // System.out.print(vexs.get(i).data + " ");
        p = vexs.get(i).firstedge;
        while (p != null) {
            if (!visited[p.adjvex]) {
                DFS(p.adjvex);
            }
            p = p.next;
        }
        //System.out.println();
    }

    public void DFSTraverse() {
        int i;
        for (i = 0; i < numVertexes; i++) {
            visited[i] = false;
        }
        for (i = 0; i < numVertexes; i++) {
            if (!visited[i]) {
                DFS(i);
            }
        }
    }
//基准法；
public void DFSAllEdges(){
    boolean []Vok = new boolean[numVertexes];
    for (int j = 0; j < numVertexes; j++) {
        Vok[j] = false;
    }
    for (int i = 0; i < numVertexes; i++) {

        VertexNode vex = vexs.get(i);
        EdgeNode node = vex.firstedge;

        while (node != null) {
            if(Vok[node.adjvex]){
                node = node.next;
                continue;
            }else {
                EdgeNode n=node.next;
                deleteEdge(node);
                for (int j = 0; j < numVertexes; j++) {
                    visited[j] = false;
                }
                DFS(node.vex);
                if(!visited[node.adjvex])
                    System.out.println("bride:(" + node.vex + ","+node.adjvex+")");
                insertEdge(node);
                node=n;
            }

        }
        Vok[i]=true;

    }
}
//

    public void UFAllEdges(){
        int oriNum= UFgetCC(-1);
        for (EdgeNode e:edgeNodeSet){
            if(notEdgesIndex.contains(e.index))
                continue;
            int deleteIndex=e.index;
           if(UFgetCC(deleteIndex)!=oriNum)
               System.out.println("("+e.vex+","+e.adjvex+")");
        }
    }

    public  void readFile(String readFile) throws IOException {
    File file = new File(readFile);
    BufferedReader reader = null;
    try {
        reader = new BufferedReader(new FileReader(file));
        String tempString;
        int index=0;
        // 一次读入一行，直到读入null为文件结束
        tempString = reader.readLine();
        numVertexes=Integer.parseInt(tempString);
        tempString = reader.readLine();
        numEdges=Integer.parseInt(tempString);
        while ((tempString = reader.readLine()) != null) {
              EdgeNode e=getData(tempString);
              e.setIndex(index);
              edgeNodeSet.add(e);
              insertEdge(e);
              index++;
        }
        reader.close();


    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        if (reader != null) {
            try {
                reader.close();
            } catch (IOException ignored) {
            }
        }
    }
}
    public  EdgeNode getData(String tempString){

        String[] strs = tempString.trim().split(" {1,}");
        int v1=Integer.parseInt(strs[0]);
        int v2=Integer.parseInt(strs[1]);
        EdgeNode e=new EdgeNode(v1,v2);
        return e;
    }
    public static void main(String[] args) throws IOException {
        int numVertexes = 16;
        int numEdges = 15;
//        int numVertexes = 50;
//        int numEdges = 147;
//        int numVertexes = 1000;
//        int numEdges = 5000;
//        int numVertexes = 1000000;
//        int numEdges = 7586063;
        Graph graph = new Graph(numVertexes, numEdges);
       //String fileName="src/Graph/data/mediumDG.txt";
        //String fileName="src/Graph/data/largeG.txt";
//        String fileName="src/Graph/data/random.txt";
//       graph.readFile(fileName);

        for (int i=0;i<numVertexes;i++){
            graph.insertVex(new VertexNode(i+""));
        }

        graph.insertEdge(new EdgeNode(0, 1,0));
        graph.insertEdge(new EdgeNode(2, 3,1));
        graph.insertEdge(new EdgeNode(2, 6,2));
        graph.insertEdge(new EdgeNode(4, 8,3));
        graph.insertEdge(new EdgeNode(4, 9,4));
        graph.insertEdge(new EdgeNode(6, 7,5));
        graph.insertEdge(new EdgeNode(8, 9,6));
        graph.insertEdge(new EdgeNode(8, 13,7));
        graph.insertEdge(new EdgeNode(9, 10,8));
        graph.insertEdge(new EdgeNode(9, 13,9));
        graph.insertEdge(new EdgeNode(10, 11,10));
        graph.insertEdge(new EdgeNode(10, 14,11));
        graph.insertEdge(new EdgeNode(11, 15,12));
        graph.insertEdge(new EdgeNode(12, 13,13));
        graph.insertEdge(new EdgeNode(14, 15,14));
        System.out.println("邻接表");
        graph.show();
//        graph.deleteEdge(new EdgeNode(0,1) );
//        graph.show();
//        System.out.print("深度优先遍历：");
     //  graph.DFSTraverse();
       // System.out.println(graph.edgeNodeSet.size());

        long startTime1=System.currentTimeMillis();
        graph.DFSAllEdges();
        //graph.UFAllEdges();
        long endTime1=System.currentTimeMillis();
        System.out.println(endTime1-startTime1+"ms");

        //System.out.println(graph.LCA_DFS_ALL());

    }

}
