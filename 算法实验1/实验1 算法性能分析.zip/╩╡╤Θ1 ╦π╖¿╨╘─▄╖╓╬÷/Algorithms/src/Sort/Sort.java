package Sort;

public class Sort {

    public static void main(String[] args) {

        for(int k=0;k<10;k++) {
            int n =600*10000;
            int maxNum = 0x7fffffff;
            int[] arr = new int[n];

            for (int i = 0; i < n; i++) {
                arr[i] = (int) (Math.random() * maxNum);
            }
//
//            int[] bArr = arr.clone();
//            //System.out.print("冒泡排序：");
//            long startTime_b = System.currentTimeMillis();    //获取开始时间
//            bubbleSort(bArr);
//            long endTime_b = System.currentTimeMillis();    //获取结束时间
//            System.out.println((endTime_b - startTime_b) + "ms");

//        int[]iArr=arr.clone();
//        //System.out.print("插入排序：");
//        long startTime_i = System.currentTimeMillis();    //获取开始时间
//        InsertionSort(iArr);
//        long endTime_i = System.currentTimeMillis();    //获取结束时间
//        System.out.println((endTime_i - startTime_i) + "ms");

//        int[]sArr=arr.clone();
//        //System.out.print("选择排序：");
//        long startTime_s = System.currentTimeMillis();    //获取开始时间
//        selectionSort(sArr);
//        long endTime_s = System.currentTimeMillis();    //获取结束时间
//        System.out.println((endTime_s - startTime_s) + "ms");


//        int[]mArr=arr.clone();
//        System.out.print("归并排序：");
//        long startTime_m = System.currentTimeMillis();
//        mergeSort(mArr, 0, mArr.length - 1);
//        long endTime_m = System.currentTimeMillis();    //获取结束时间
//        System.out.println( (endTime_m - startTime_m) + "ms");

        int[]qArr=arr.clone();
        System.out.print("快速排序：");
        int len = qArr.length;
        long startTime_q = System.currentTimeMillis();
        quickSort(qArr,0,len-1);
        long endTime_q = System.currentTimeMillis();    //获取结束时间
        System.out.println( (endTime_q - startTime_q) + "ms");

        }

    }
    //冒泡排序
    public static void bubbleSort(int[] arr) {
        int len=arr.length;
        for(int i =0 ; i<len-1 ; i++) {
            for(int j=0 ; j<len-1-i ; j++) {
                if(arr[j]>arr[j+1]) {
                    swap(arr, j,j+1);
                }
            }
        }
    }

    //选择排序
    public static void selectionSort(int[] arr){
        int len=arr.length;
        for(int i = 0; i < len - 1; i++){
            int minIndex = i;// 用于记录最小数的索引，初始化为数组第一个元素
            for(int j = i + 1; j < len; j++){//循环找出最小数
                if(arr[j] < arr[minIndex]){
                    minIndex = j;
                }
            }
            //一轮循环将最小数放到未排序的序列首位
            swap(arr, i, minIndex);
        }
    }
    //插入排序
    public static void InsertionSort(int[] arr)
    {
        int len=arr.length;
        //从序列第二个数开始，往前比较
        for (int i=1;i<len;i++) {
            for (int j = i; j > 0; j--) {
                //如比前面的数小，则交换位置
                if (arr[j] < arr[j - 1])
                    swap(arr, j, j - 1);
                else break;
                //默认前面序列都是排好有序的
            }
        }
    }
    //合并排序
    public static int[] mergeSort(int[] arr, int l, int h) {
        //两个指针分别指向序列起始位置
        if (l == h)
            return new int[] { arr[l] };

        int mid = l + (h - l) / 2;
        //递归拆分
        int[] leftArr = mergeSort(arr, l, mid); //左有序数组
        int[] rightArr = mergeSort(arr, mid + 1, h); //右有序数组
        //申请空间用于存放合并后的序列
        int[] newArr = new int[leftArr.length + rightArr.length];
        //合并两个有序序列“二路归并”
        int m = 0, i = 0, j = 0;
        while (i < leftArr.length && j < rightArr.length) {
            newArr[m++] = leftArr[i] < rightArr[j] ? leftArr[i++] : rightArr[j++];
        }
        while (i < leftArr.length)
            newArr[m++] = leftArr[i++];
        while (j < rightArr.length)
            newArr[m++] = rightArr[j++];
        return newArr;
    }
    //快速排序
    public static void quickSort(int[] arr, int start, int end) {
        int i,j,pivot;
        if(start>end){
            return ;
        }
        i=start;
        j=end;
        //基准位
        pivot = arr[start];
        while (i<j) {
            //先看右边，依次往左递减
            while (pivot<=arr[j]&&i<j) {
                j--;
            }
            //再看左边，依次往右递增
            while (pivot>=arr[i]&&i<j) {
                i++;
            }
            //如果满足条件则交换
            if (i<j) swap(arr,i,j);
        }
        //最后将基准为与i和j相等位置的数字交换
        arr[start] = arr[i];
        arr[i] = pivot;
        //递归调用左半数组
        quickSort(arr, start, j-1);
        //递归调用右半数组
        quickSort(arr, j+1, end);
    }
    //两个元素交换
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
