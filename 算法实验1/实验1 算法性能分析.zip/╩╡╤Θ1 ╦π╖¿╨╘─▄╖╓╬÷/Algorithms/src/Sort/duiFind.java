package Sort;

import java.util.Arrays;

public class duiFind {
    static final int K=10;
    static int[] arr;                //定义待排序数组
    static int[] topK=new int[K];
    public static void main(String[] args) {
            getArr();

        long startTime_h = System.currentTimeMillis();
            buildHeap();//建立小顶堆并排序
        long endTime_h = System.currentTimeMillis();
        System.out.println( "堆："+(endTime_h - startTime_h) + "ms");

        System.out.print(Arrays.toString(topK));

//        int [] qArr=arr.clone();
//        int len = qArr.length;
//        long startTime_q = System.currentTimeMillis();
//        quickSort(qArr,0,len-1);
//        long endTime_q = System.currentTimeMillis();
//        System.out.println( "\n快速排序："+(endTime_q - startTime_q) + "ms");
//        for(int i=0;i<K;i++)
//        System.out.print(qArr[i]+"\t");

//        int [] sArr=arr.clone();
//        long startTime_s = System.currentTimeMillis();
//        selectionSort(sArr);
//        long endTime_s = System.currentTimeMillis();
//        System.out.println( "\n选择排序："+(endTime_s - startTime_s) + "ms");
//        for(int i=0;i<K;i++)
//            System.out.print(sArr[i]+"\t");
    }
    private static void getArr() {
        int n=10000*10000;//输入规模
        int maxNum=0x7fffffff;//int最大数
         arr = new int[n];
        //随机产生序列
        for(int i=0;i<n;i++) {
            arr[i] = (int) (Math.random() * maxNum);
        }
    }

    private static void getTopK() {
            int num=K;
            for (int i=0;i<num;i++){
                topK[i]=arr[i];
            }
    }
        private static void buildHeap() {
            getTopK();//拿到序列前十个数
            int len_ten = topK.length;//K
            int len_arr=arr.length;
            for(int i =len_ten/2 -1 ;i>=0;i--)  //拿这10个数建立小顶堆
            {
                sortHeap(i,len_ten);
            }
          //依次比较（放入）后续元素
            for (int i=len_ten;i<len_arr;i++){
                if(topK[0]<arr[i]){//比堆顶元素大则覆盖
                    topK[0]=arr[i];
                    sortHeap(0,len_ten);
                }
            }
            for(int j = len_ten-1; j >0; j --) //对堆进行排序
            {
                swap(topK,0,j);
                sortHeap(0,j);
            }
        }

        private static void sortHeap(int i, int len) {
        //找出最小数——堆顶
            int left = 2*i+1;         //定义左节点
            int right = 2*i +2;     //定义右节点
            int min ;         //存放三个节点中最小节点的下标
            if(len >left && topK[left] <topK[i])    //假设左孩子小于根节点 将左孩子下标赋值给min
                min = left;
            else           //否之。将根节点下标赋值给min
                min = i;
            if(len > right && topK[right] < topK[min])
                min = right;   //若右孩子节点小于根节点，把右孩子节点下标赋值给min

            if(min != i)       //若最小节点的下标不等于根节点的下标时，交换其值
            {
                swap(topK,min,i);
                sortHeap(min,len);
            }
        }
    //快速排序
    public static void quickSort(int[] arr, int start, int end) {
        int i,j,pivot;
        if(start>end){return ;}
        i=start;
        j=end;
        //基准位
        pivot = arr[start];
        while (i<j) {
            //先看右边，依次往左递减
            while (pivot>=arr[j]&&i<j) {j--;}
            //再看左边，依次往右递增
            while (pivot<=arr[i]&&i<j) {i++;}
            //如果满足条件则交换
            if (i<j) swap(arr,i,j);
        }
        //最后将基准为与i和j相等位置的数字交换
        arr[start] = arr[i];
        arr[i] = pivot;
        //递归调用左半数组
        quickSort(arr, start, j-1);
        //递归调用右半数组
        quickSort(arr, j+1, end);
    }
    //选择排序
    public static void selectionSort(int[] arr){
        int len=arr.length;
        for(int i = 0; i < K; i++){
            int maxIndex = i;// 用于记录最大数的索引，初始化为数组第一个元素
            for(int j = i + 1; j < len; j++){//循环找出最da数
                if(arr[j] >arr[maxIndex]){
                    maxIndex = j;
                }
            }
            //一轮循环将最大数放到未排序的序列首位
            swap(arr, i, maxIndex);
        }
    }
        //交换相应下标值
        private static void swap(int[]arr,int m, int n) {
            int temp ;
            temp = arr[m];
            arr[m] = arr[n];
            arr[n] = temp;
        }

}
